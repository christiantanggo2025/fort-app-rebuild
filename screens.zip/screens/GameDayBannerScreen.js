import React, { useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Platform,
  Modal,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { supabase } from '../lib/supabase';

const bannerPhases = [
  { key: 'no_games', label: 'No Games Scheduled', color: '#999' },
  { key: 'games_on', label: 'Games Are On', color: '#00AA00' },
  { key: 'cancelled', label: 'Games Cancelled', color: '#FF0000' },
  { key: 'pending', label: 'Games Pending', color: '#FFD700' },
  { key: 'free_practice', label: 'Free Practice Today', color: '#007FFF' },
];

export default function GameDayBannerScreen() {
  const navigation = useNavigation();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedPhase, setSelectedPhase] = useState(null);
  const [repeatDay, setRepeatDay] = useState(false);
  const [showPicker, setShowPicker] = useState(false);
  const [dropdownVisible, setDropdownVisible] = useState(false);

  const handleDateChange = (_, date) => {
    setShowPicker(false);
    if (date) setSelectedDate(date);
  };

  const saveBanner = async () => {
    if (!selectedPhase) {
      Alert.alert('Select a phase before saving.');
      return;
    }

    const payload = {
      status: selectedPhase,
      banner_date: selectedDate.toISOString().split('T')[0],
    };

    if (repeatDay) {
      const weekday = selectedDate.toLocaleString('en-US', { weekday: 'long' }).toLowerCase();
      payload.repeat_day = weekday;
    }

    const { error } = await supabase
      .from('volleyball_banners')
      .upsert(payload, { onConflict: ['banner_date'] });

    if (error) {
      Alert.alert('Error', error.message);
    } else {
      Alert.alert('Success', 'Banner phase updated.');
    }
  };

  const selectedLabel =
    bannerPhases.find((p) => p.key === selectedPhase)?.label || 'Select Phase';

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerText}>Game Day Banner</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.container}>
        {/* Date Picker */}
        <TouchableOpacity onPress={() => setShowPicker(true)} style={styles.dateButton}>
          <Text style={styles.dateText}>
            {selectedDate.toDateString()}
          </Text>
        </TouchableOpacity>
        {showPicker && (
          <DateTimePicker
            value={selectedDate}
            mode="date"
            display={Platform.OS === 'ios' ? 'inline' : 'default'}
            onChange={handleDateChange}
          />
        )}

        {/* Phase Dropdown */}
        <Text style={styles.label}>Select Banner Phase:</Text>
        <TouchableOpacity
          style={styles.dropdownField}
          onPress={() => setDropdownVisible(true)}
        >
          <Text style={styles.dropdownText}>{selectedLabel}</Text>
          <Ionicons name="chevron-down" size={20} color="#333" />
        </TouchableOpacity>

        <Modal
          transparent
          visible={dropdownVisible}
          animationType="fade"
          onRequestClose={() => setDropdownVisible(false)}
        >
          <TouchableOpacity
            style={styles.modalBackdrop}
            onPress={() => setDropdownVisible(false)}
          >
            <View style={styles.dropdownList}>
              {bannerPhases.map((phase) => (
                <TouchableOpacity
                  key={phase.key}
                  style={styles.dropdownItem}
                  onPress={() => {
                    setSelectedPhase(phase.key);
                    setDropdownVisible(false);
                  }}
                >
                  <Text>{phase.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </TouchableOpacity>
        </Modal>

        {/* Repeat Toggle */}
        <TouchableOpacity
          style={[styles.button, repeatDay && styles.toggleActive]}
          onPress={() => setRepeatDay(!repeatDay)}
        >
          <Text style={styles.buttonText}>
            {repeatDay ? '✓ Repeat Every Week' : 'Repeat Every Week'}
          </Text>
        </TouchableOpacity>

        {/* Save Button */}
        <TouchableOpacity style={styles.button} onPress={saveBanner}>
          <Text style={styles.buttonText}>Save Banner</Text>
        </TouchableOpacity>

        {/* View Past Dates Button - Teal */}
        <TouchableOpacity
          style={[styles.button, { marginTop: 20 }]}
          onPress={() => navigation.navigate('ViewBannerHistoryScreen')}
        >
          <Text style={styles.buttonText}>View Past Dates</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#fff' },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  headerText: {
    flex: 1,
    textAlign: 'center',
    fontSize: 20,
    fontWeight: 'bold',
  },
  container: {
    padding: 20,
  },
  dateButton: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    padding: 14,
    alignItems: 'center',
    marginBottom: 20,
  },
  dateText: {
    fontSize: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  dropdownField: {
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    padding: 14,
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  dropdownText: {
    fontSize: 16,
    color: '#333',
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.2)',
    justifyContent: 'center',
    padding: 20,
  },
  dropdownList: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 10,
    elevation: 4,
  },
  dropdownItem: {
    paddingVertical: 12,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: '#008080',
    padding: 14,
    borderRadius: 10,
    marginBottom: 12,
  },
  toggleActive: {
    backgroundColor: '#004d4d',
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
  },
});

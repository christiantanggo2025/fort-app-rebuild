import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../lib/supabase';
import { useNavigation } from '@react-navigation/native';

export default function SubmitScoresScreen() {
  const navigation = useNavigation();
  const [matchList, setMatchList] = useState([]);
  const [scoreData, setScoreData] = useState({});

  useEffect(() => {
    fetchMatches();
  }, []);

  const fetchMatches = async () => {
    const { data, error } = await supabase.from('schedules').select('*');
    if (error) {
      console.error('Error fetching schedules:', error);
    } else {
      setMatchList(data);
    }
  };

  const handleScoreChange = (matchId, team, value) => {
    setScoreData((prev) => ({
      ...prev,
      [matchId]: {
        ...prev[matchId],
        [team]: value,
      },
    }));
  };

  const handleSubmit = async (match) => {
    const entry = scoreData[match.id];
    if (!entry?.team1Score || !entry?.team2Score) {
      Alert.alert('Missing scores', 'Please enter both team scores before submitting.');
      return;
    }

    const winner_team =
      parseInt(entry.team1Score) > parseInt(entry.team2Score)
        ? match.team1
        : parseInt(entry.team2Score) > parseInt(entry.team1Score)
        ? match.team2
        : 'Draw';

    const { error } = await supabase.from('score_submissions').insert([
      {
        match_id: match.id,
        submitted_by: 'Team A', // TODO: Replace with actual user’s team
        team1_score: parseInt(entry.team1Score),
        team2_score: parseInt(entry.team2Score),
        winner_team,
        is_approved: false,
      },
    ]);

    if (error) {
      console.error('❌ Submit error:', error);
      Alert.alert('Error', 'Could not submit score.');
    } else {
      Alert.alert('✅ Submitted', 'Your score was submitted!');
      fetchMatches(); // Refresh or navigate if needed
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerText}>Submit Scores</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.container}>
        {matchList.map((match) => (
          <View key={match.id} style={styles.card}>
            <Text style={styles.matchText}>
              {match.team1} vs {match.team2}
            </Text>
            <View style={styles.inputRow}>
              <TextInput
                style={styles.input}
                keyboardType="numeric"
                placeholder="Score"
                value={scoreData[match.id]?.team1Score || ''}
                onChangeText={(value) => handleScoreChange(match.id, 'team1Score', value)}
              />
              <TextInput
                style={styles.input}
                keyboardType="numeric"
                placeholder="Score"
                value={scoreData[match.id]?.team2Score || ''}
                onChangeText={(value) => handleScoreChange(match.id, 'team2Score', value)}
              />
            </View>
            <TouchableOpacity
              style={styles.submitButton}
              onPress={() => handleSubmit(match)}
            >
              <Text style={styles.submitButtonText}>Submit Score</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#fff' },
  headerRow: {
    flexDirection: 'row',
    padding: 20,
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  container: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  card: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
  },
  matchText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  inputRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 10,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 10,
  },
  submitButton: {
    backgroundColor: '#008080',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  submitButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

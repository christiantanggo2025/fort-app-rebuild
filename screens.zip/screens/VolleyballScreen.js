import React, { useEffect, useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  Image,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { supabase } from '../lib/supabase';
import { Linking } from 'react-native';

const { width } = Dimensions.get('window');

const defaultCarouselImages = [
  require('../assets/logo.png'),
  require('../assets/FortLogo.png'),
];

const bannerColors = {
  no_games: '#999999',
  games_on: '#00AA00',
  cancelled: '#FF0000',
  pending: '#FFD700',
  free_practice: '#007FFF',
};

const bannerMessages = {
  no_games: 'No Games Scheduled For Today',
  games_on: 'Games For Today Are On',
  cancelled: 'Games For Today Are Cancelled',
  pending: 'Games For Today Are Pending',
  free_practice: 'Free Practice Today',
};

export default function VolleyballScreen() {
  const navigation = useNavigation();
  const [upcomingMatches, setUpcomingMatches] = useState([]);
  const [topTeams, setTopTeams] = useState([]);
  const [nextScheduleDate, setNextScheduleDate] = useState(null);
  const [carouselImages, setCarouselImages] = useState([]);
  const [carouselIndex, setCarouselIndex] = useState(0);
  const [bannerStatus, setBannerStatus] = useState('no_games');

  useFocusEffect(
    React.useCallback(() => {
      fetchNextRound();
      fetchTopTeams();
      fetchCarouselImages();
      fetchBannerStatus();
      autoApproveAndUpdateStandings();

      const interval = setInterval(() => {
        setCarouselIndex((prev) => (prev + 1) % (carouselImages.length || defaultCarouselImages.length));
      }, 4000);

      return () => clearInterval(interval);
    }, [carouselImages.length])
  );

  const fetchNextRound = async () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const { data, error } = await supabase
      .from('schedules')
      .select('*')
      .order('match_date', { ascending: true });

    if (error) return;

    const groupedByDate = {};
    data.forEach((match) => {
      if (!groupedByDate[match.match_date]) {
        groupedByDate[match.match_date] = [];
      }
      groupedByDate[match.match_date].push(match);
    });

    const sortedDates = Object.keys(groupedByDate).sort();
    for (let date of sortedDates) {
      const matchDate = new Date(date);
      if (matchDate >= today) {
        setUpcomingMatches(groupedByDate[date].filter((m) => m.round === 1));
        setNextScheduleDate(matchDate.toDateString());
        break;
      }
    }
  };

  const fetchTopTeams = async () => {
    const { data, error } = await supabase
      .from('volleyball_scores_summary')
      .select('*')
      .order('points', { ascending: false })
      .limit(5);

    if (!error) setTopTeams(data);
  };

  const fetchCarouselImages = async () => {
    const { data, error } = await supabase
      .from('volleyball_carousel')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data.length > 0) {
      setCarouselImages(data.map((img) => ({ uri: img.image_url })));
    }
  };

  const fetchBannerStatus = async () => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    const weekday = today.toLocaleString('en-US', { weekday: 'long' }).toLowerCase();

    const { data: specific } = await supabase
      .from('volleyball_banners')
      .select('*')
      .eq('banner_date', todayStr)
      .single();

    if (specific?.status) {
      setBannerStatus(specific.status);
      return;
    }

    const { data: recurring } = await supabase
      .from('volleyball_banners')
      .select('*')
      .eq('repeat_day', weekday)
      .single();

    if (recurring?.status) {
      setBannerStatus(recurring.status);
    } else {
      setBannerStatus('no_games');
    }
  };

  const autoApproveAndUpdateStandings = async () => {
    try {
      const { error } = await supabase.rpc('resolve_score_conflicts_and_update_standings');
      if (error) {
        console.error('❌ Auto-approval error:', error);
      } else {
        console.log('✅ Auto-approved & updated standings');
      }
    } catch (e) {
      console.error('❌ Unexpected error:', e);
    }
  };

  const handleRegisterButton = async () => {
    const { data } = await supabase
      .from('app_links')
      .select('registration_link')
      .eq('id', 1)
      .single();

    if (data?.registration_link) {
      Linking.openURL(data.registration_link);
    } else {
      Alert.alert('No Link Available', 'Please check back later.');
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* Header */}
        <View style={styles.headerRow}>
          <View style={{ width: 28 }} />
          <Text style={styles.headerText}>Volleyball</Text>
          <TouchableOpacity
            style={styles.accountIcon}
            onPress={() => navigation.navigate('CustomerAccountScreen')}
          >
            <Ionicons name="person-circle-outline" size={28} color="black" />
          </TouchableOpacity>
        </View>

        {/* Banner */}
        <View style={[styles.phaseBanner, { backgroundColor: bannerColors[bannerStatus] || '#999' }]}>
          <Text style={styles.phaseText}>{bannerMessages[bannerStatus]}</Text>
        </View>

        {/* Captain Login */}
        <TouchableOpacity
          style={[styles.button, styles.fullWidth]}
          onPress={() => navigation.navigate('CaptainLogin')}
        >
          <Text style={styles.buttonText}>Captain Login</Text>
        </TouchableOpacity>

        {/* Carousel */}
        <View style={styles.carouselBox}>
          <Image
            source={
              carouselImages.length > 0
                ? carouselImages[carouselIndex]
                : defaultCarouselImages[carouselIndex % defaultCarouselImages.length]
            }
            style={styles.carouselImage}
            resizeMode="cover"
          />
        </View>

        {/* Schedule */}
        <View style={[styles.section, styles.centeredSection]}>
          <Text style={styles.sectionHeader}>Upcoming Schedule</Text>
          {nextScheduleDate && (
            <Text style={styles.scheduleDate}>{nextScheduleDate}</Text>
          )}
          {upcomingMatches.length === 0 ? (
            <Text style={styles.sectionText}>Loading...</Text>
          ) : (
            upcomingMatches.map((match, index) => (
              <Text key={index} style={styles.sectionText}>
                Court {match.court}: {match.team1} vs {match.team2}
              </Text>
            ))
          )}
          <TouchableOpacity onPress={() => navigation.navigate('ViewSchedule')}>
            <Text style={styles.linkText}>View Full Schedule</Text>
          </TouchableOpacity>
        </View>

        {/* Top 5 Teams */}
        <View style={[styles.section, styles.centeredSection]}>
          <Text style={styles.sectionHeader}>Top 5 Teams</Text>
          {topTeams.length === 0 ? (
            <Text style={styles.sectionText}>Loading...</Text>
          ) : (
            topTeams.map((team, index) => (
              <View key={index} style={styles.badgeRow}>
                <View style={styles.badge}>
                  <Text style={[styles.badgeText, index === 0 && styles.goldBadge]}>
                    {index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : index + 1}
                  </Text>
                </View>
                <Text style={styles.teamText}>
                  {team.team_name} – {team.points} pts
                </Text>
              </View>
            ))
          )}
          <TouchableOpacity onPress={() => navigation.navigate('StandingsScreen')}>
            <Text style={styles.linkText}>View Full Standings</Text>
          </TouchableOpacity>
        </View>

        {/* Store + Register Buttons */}
        <TouchableOpacity
          style={[styles.button, styles.fullWidth]}
          onPress={() => Alert.alert('Feature Coming Soon')}
        >
          <Text style={styles.buttonText}>Volleyball Store</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, styles.fullWidth]}
          onPress={handleRegisterButton}
        >
          <Text style={styles.buttonText}>Register Your Team</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Bottom Bar */}
      <View style={styles.bottomBar}>
        <TouchableOpacity
          style={styles.iconButton}
          onPress={() => navigation.navigate('CustomerAppDashboard')}
        >
          <Ionicons name="home-outline" size={26} color="#008080" />
          <Text style={styles.iconLabel}>Home</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.iconButton}
          onPress={() => alert('Entertainment section coming soon.')}
        >
          <Ionicons name="musical-notes-outline" size={26} color="#008080" />
          <Text style={styles.iconLabel}>Entertainment</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.iconButton}
          onPress={() => navigation.navigate('Volleyball')}
        >
          <Ionicons name="football-outline" size={26} color="#008080" />
          <Text style={styles.iconLabel}>Volleyball</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#fff' },
  scrollContainer: { padding: 20, paddingBottom: 100 },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  headerText: { fontSize: 24, fontWeight: 'bold', color: '#000' },
  accountIcon: { width: 28, height: 28 },
  phaseBanner: {
    width: '100%',
    paddingVertical: 12,
    paddingHorizontal: 8,
    marginBottom: 10,
  },
  phaseText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#008080',
    padding: 12,
    borderRadius: 10,
    marginVertical: 10,
  },
  fullWidth: {
    alignSelf: 'stretch',
  },
  buttonText: { color: '#fff', textAlign: 'center', fontWeight: 'bold' },
  section: { marginTop: 20 },
  centeredSection: { alignItems: 'center' },
  sectionHeader: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 10,
  },
  sectionText: { fontSize: 16, color: '#000', marginVertical: 2 },
  scheduleDate: { fontSize: 16, color: '#008080', marginBottom: 10 },
  linkText: {
    fontSize: 14,
    color: '#008080',
    textDecorationLine: 'underline',
    marginTop: 10,
  },
  badgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  badge: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#008080',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  badgeText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  goldBadge: {
    fontSize: 18,
  },
  teamText: {
    fontSize: 16,
    color: '#000',
    fontWeight: '500',
  },
  carouselBox: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: 10,
    overflow: 'hidden',
    marginVertical: 20,
  },
  carouselImage: {
    width: '100%',
    height: '100%',
  },
  bottomBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: '#ccc',
    backgroundColor: '#f9f9f9',
  },
  iconButton: { alignItems: 'center' },
  iconLabel: { fontSize: 12, color: '#008080' },
});
